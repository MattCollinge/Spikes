﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace EventReceiver.WinUI
{
    [ServiceBehavior(UseSynchronizationContext = false)]
    public class FeedbackListenerService : IFeedbackListenerService
    {

        public void ReceiveEvents(string reqType, long eventCount)
        {
            try
            {
                UpdateGridDelegate handler = GridUpdater;
                if (handler != null)
                {
                    handler(this, new UpdateGridEventArgs(reqType, eventCount));
                }
            }
            catch { }
        }


        public static UpdateGridDelegate GridUpdater { get; set; }
    }

    public delegate void UpdateGridDelegate(object sender, UpdateGridEventArgs e);

    public class UpdateGridEventArgs 
    { 
        public string ReqType { get; set; }
        public long Count { get; set; }
        public UpdateGridEventArgs(string req, long count) 
        {
            ReqType = req;
            Count = count;
        } 
    } 
}
