﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.ServiceModel;
using System.Windows.Forms.DataVisualization.Charting;

namespace EventReceiver.WinUI
{
    public partial class CallCenterDashboard : Form
    {
        private ServiceHost host;

        public CallCenterDashboard()
        {
            InitializeComponent();

            FeedbackListenerService.GridUpdater = UpdateGrid;

            host = new ServiceHost(typeof(FeedbackListenerService));
        }

       
        private void btnStart_Click(object sender, EventArgs e)
        {
            host.Open();
            lblHostStatus.Text = "Open";

            //create chart
            DateTime minValue = DateTime.Now;
            DateTime maxValue = minValue.AddSeconds(30);

            chart1.ChartAreas[0].AxisX.Minimum = minValue.ToOADate();
            chart1.ChartAreas[0].AxisX.Maximum = maxValue.ToOADate();

        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            host.Close();
            lblHostStatus.Text = "Closed";
        }

        public void UpdateGrid(object sender, UpdateGridEventArgs args)
        {
            Invoke((MethodInvoker) delegate
            {
                DateTime timeStamp = DateTime.Now;
                Series ptSeries1 = chart1.Series["Orders"];
                Series ptSeries2 = chart1.Series["Complaints"];
                Series ptSeries3 = chart1.Series["Info Requests"];

                if (args.ReqType == "Order")
                {
                    // Add new data point to its series.
                    ptSeries1.Points.AddXY(timeStamp.ToOADate(), args.Count);

                    // remove all points from the source series older than 1.5 minutes.
                    double removeBefore = timeStamp.AddSeconds((double)(90) * (-1)).ToOADate();
                    //remove oldest values to maintain a constant number of data points
                    while (ptSeries1.Points[0].XValue < removeBefore)
                    {
                        ptSeries1.Points.RemoveAt(0);
                    }
                }
                if (args.ReqType == "Complaint")
                {
                    // Add new data point to its series.
                    ptSeries2.Points.AddXY(timeStamp.ToOADate(), args.Count);

                    // remove all points from the source series older than 1.5 minutes.
                    double removeBefore = timeStamp.AddSeconds((double)(90) * (-1)).ToOADate();
                    //remove oldest values to maintain a constant number of data points
                    while (ptSeries2.Points[0].XValue < removeBefore)
                    {
                        ptSeries2.Points.RemoveAt(0);
                    }
                }
                if (args.ReqType == "Info Request")
                {
                    // Add new data point to its series.
                    ptSeries3.Points.AddXY(timeStamp.ToOADate(), args.Count);

                    // remove all points from the source series older than 1.5 minutes.
                    double removeBefore = timeStamp.AddSeconds((double)(90) * (-1)).ToOADate();
                    //remove oldest values to maintain a constant number of data points
                    while (ptSeries3.Points[0].XValue < removeBefore)
                    {
                        ptSeries3.Points.RemoveAt(0);
                    }
                }

                if (ptSeries1.Points.Count > 0)
                {
                    chart1.ChartAreas[0].AxisX.Minimum = ptSeries1.Points[0].XValue;
                    chart1.ChartAreas[0].AxisX.Maximum = DateTime.FromOADate(ptSeries1.Points[0].XValue).AddMinutes(2).ToOADate();
                }
                chart1.Invalidate();
            });
            
        }
    }
}
