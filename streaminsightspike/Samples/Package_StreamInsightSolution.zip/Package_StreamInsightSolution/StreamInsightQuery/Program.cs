﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#region Additional Using Statements
using DataPublisher;
using StreamInsight.Samples.Adapters.OutputTracer;
using System.ServiceModel;
using Microsoft.ComplexEventProcessing;
using Microsoft.ComplexEventProcessing.Linq;
using Microsoft.ComplexEventProcessing.ManagementService;
using WebOutputAdapter;
#endregion

namespace StreamInsightQuery
{
    class Program
    {
        static void Main(string[] args)
        {
            UseEmbeddedHost();
        }

        static private void UseEmbeddedHost()
        {
            Console.WriteLine("*** Create Server *** ");

            //create reference to standalone server
            using (Server server = Server.Create("RSEROTERv2"))
            {
                #region Management Endpoint Configuration
                //**NOTE you can comment this out if you aren't doing any tracing
                // Create a service host to expose the server's endpoint for management purposes
                //ServiceHost host = new ServiceHost(server.CreateManagementService());
                //WSHttpBinding binding = new WSHttpBinding(SecurityMode.Message);
                //binding.HostNameComparisonMode = HostNameComparisonMode.Exact;
                //make sure that your endpoint has the appropriate rights established through netsh
                //host.AddServiceEndpoint(typeof(IManagementService),
                //                        binding,
                //                        "http://localhost:8089/StreamInsight/RSEROTERv2");

                //If you want to run the debugger, start the host
                //host.Open();
                #endregion

                #region Input Adapter Config
                var config = new CallCenterAdapterConfig()
                {
                    CtiFrequency = 1
                };
                #endregion

                #region Target Adapter Config
                var webAdapterConfig = new WebOutputConfig()
                {
                    HttpMethod = "POST",
                    IsSoap = true,
                    //change to your service address
                    ServiceAddress = "http://localhost:8732/EventReceiver.WinUI/FeedbackListenerService",
                    SoapAction = "http://tempuri.org/IFeedbackListenerService/ReceiveEvents",
                    //change to your XSL path
                    XslPath = @"C:\Users\rseroter\Documents\Visual Studio 2010\Projects\Package_StreamInsightSolution\CallCenterEvent_To_EventDashboardService.xslt"
                };
                
                var tracerConfig = new TracerConfig()
                {
                    DisplayCtiEvents = false,
                    SingleLine = true,
                    TraceName = "Trace",
                    TracerKind = StreamInsight.Samples.Adapters.OutputTracer.TracerKind.Console
                    //TraceType = TraceTypeValue.File
                };
                #endregion

                try
                {
                    //create new application on the server
                    var myApp = server.CreateApplication("CallCenterEvents");

                    //get reference to input stream
                    var inputStream = CepStream<CallCenterRequestEventType>.Create("input", typeof(CallCenterAdapterFactory), config, EventShape.Point);

                    #region Query 1 - Select All
                    //select all
                    var query1 = from e in inputStream
                                    select e;
                    #endregion

                    #region Query 2 - Filter
                    //filter
                    var query2 = from e in inputStream
                                 where e.RequestType == "Complaint"
                                 select e;
                    #endregion

                    #region Query 3 - Events in a Window
                    //events in tumbling window that resets every 10 seconds
                    var query3 = from e in inputStream
                                 group e by e.RequestType into requestGroup
                                 from x in requestGroup.TumblingWindow(TimeSpan.FromSeconds(10), HoppingWindowOutputPolicy.ClipToWindowEnd)
                                 select new
                                 {
                                     RequestType = requestGroup.Key,
                                     WindowCount = x.Count()
                                 };
                    #endregion

                    #region Query 4 - Events in Hopping Window
                    //events in a hopping window that hops each 2 seconds
                    var query4 = from e in inputStream
                                 group e by e.RequestType into requestGroup
                                 from x in requestGroup.HoppingWindow(TimeSpan.FromSeconds(10), TimeSpan.FromSeconds(2), HoppingWindowOutputPolicy.ClipToWindowEnd)
                                 select new CallEventSummary
                                 {
                                     RequestType = requestGroup.Key,
                                     TotalRequests = x.Count()
                                 };
                    #endregion

                    #region Query 5 - Running Totals Over Time
                    //running total of orders over a 10 second time period (emitted as received)
                    long PeriodAsTicks = TimeSpan.TicksPerSecond * 10;
                    var query5 = from e in inputStream
                                 .Where(f => f.RequestType == "Order")
                                 .AlterEventDuration(f => TimeSpan.FromTicks(PeriodAsTicks - (f.StartTime.Ticks % PeriodAsTicks)))
                                 .SnapshotWindow(SnapshotWindowOutputPolicy.Clip)
                                 select new
                                 {
                                     RunningTotal = e.Count()
                                 };
                    #endregion

                    #region Query 6 - Running Totals Over Time By Type
                    //running totals for each type over a 90 second time period (emitted as received)
                    long DashboardPeriodAsTicks = TimeSpan.TicksPerSecond * 90;
                    var query6 = from e in inputStream
                                 .AlterEventDuration(f => TimeSpan.FromTicks(DashboardPeriodAsTicks - (f.StartTime.Ticks % DashboardPeriodAsTicks)))
                                 group e by e.RequestType into requestGroups
                                 from win in requestGroups
                                 .SnapshotWindow(SnapshotWindowOutputPolicy.Clip)
                                 select new CallEventSummary
                                 {
                                     RequestType = requestGroups.Key,
                                     TotalRequests = win.Count()
                                 };
                    #endregion

                    //start SI query for queries #1-5
                    #region Tracer Adapter Query

                    var siQuery = query4.ToQuery(myApp, "SI Query", string.Empty, typeof(TracerFactory), tracerConfig, EventShape.Point, StreamEventOrder.FullyOrdered);

                    #endregion

                    //start SI query for query #6
                    #region Web Adapter Query

                    //var siQuery = query6.ToQuery(myApp, "SI Query", string.Empty, typeof(WebOutputFactory), webAdapterConfig, EventShape.Point, StreamEventOrder.FullyOrdered);

                    #endregion
                    
                    siQuery.Start();

                    //wait for keystroke to end
                    Console.ReadLine();

                    siQuery.Stop();
                    //host.Close();
                    Console.WriteLine("Query stopped. Press enter to exit application.");
                    Console.ReadLine();

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    Console.ReadLine();
                }
            }
        }

    }
}
