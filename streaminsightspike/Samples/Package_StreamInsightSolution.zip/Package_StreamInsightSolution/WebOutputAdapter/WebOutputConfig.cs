﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebOutputAdapter
{
    public struct WebOutputConfig
    {
        public string XslPath { get; set; }
        public string ServiceAddress { get; set; }
        public string HttpMethod { get; set; }
        public string SoapAction { get; set; }
        public bool IsSoap { get; set; }

    }
}
