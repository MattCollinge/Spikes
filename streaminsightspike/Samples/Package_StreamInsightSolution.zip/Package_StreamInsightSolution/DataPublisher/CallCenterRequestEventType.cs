﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Security.Cryptography;

namespace DataPublisher
{
    public class CallCenterRequestEventType
    {
        /// <summary>
        /// Initiatize new instance of the call center request
        /// </summary>
        public CallCenterRequestEventType()
        {
            this.CustomerId = GetRandomNumber(25000).ToString();
            this.RequestType = requestList[GetRandomNumber(3)];
            this.Product = productList[GetRandomNumber(5)];
        }

        /// <summary>
        /// Gets or sets request type
        /// </summary>
        public string RequestType { get; set; }
        /// <summary>
        /// Gets or sets product name
        /// </summary>
        public string Product { get; set; }
        /// <summary>
        /// Gets or sets customer ID
        /// </summary>
        public string CustomerId { get; set; }

        /// <summary>
        /// Creates a random number
        /// </summary>
        /// <param name="maxValue"></param>
        /// <returns></returns>
        private static int GetRandomNumber(int maxValue)
        {
            RandomNumberGenerator rng = RNGCryptoServiceProvider.Create();
            byte[] bytes = new byte[4];
            rng.GetBytes(bytes);
            int rndNum = BitConverter.ToInt32(bytes, 0);
            return Math.Abs(rndNum % maxValue);
        }

        /// <summary>
        /// Array for types of requests
        /// </summary>
        string[] requestList = new string[]{"Order", "Complaint", "Info Request"};

        /// <summary>
        /// Array of products
        /// </summary>
        string[] productList = new string[]{
            "Happy Fun Ball", 
            "Lil' Slugger Brass Knuckles", 
            "Bag o' Nails",
            "My First Handcuffs", 
            "Sleepy Pimp Action Figure"};
    }
}
