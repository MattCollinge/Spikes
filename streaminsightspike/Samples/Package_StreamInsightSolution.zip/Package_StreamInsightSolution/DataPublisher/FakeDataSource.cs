﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataPublisher
{
    public class FakeDataSource
    {
        public FakeDataSource()
        {
            //how long to wait between generated messages
            this.period = 500;
            this.variance = 0;

            // Initalize timer.
            this.timer = new System.Timers.Timer(period);
            this.timer.Elapsed += new System.Timers.ElapsedEventHandler(this.productData);
            this.timer.AutoReset = true;
        }

        /// <summary>
        /// Sets the callback.
        /// </summary>
        public EventCallback Callback
        {
            set { this.callback = value; }
        }

        /// <summary>
        /// Starts the data generation.
        /// </summary>
        public void Start()
        {
            this.timer.Enabled = true;
        }

        /// <summary>
        /// Stops the data generation.
        /// </summary>
        public void Stop()
        {
            this.timer.Enabled = false;
        }

        /// <summary>
        /// Generates data and calls the callback
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void productData(object sender, System.Timers.ElapsedEventArgs e)
        {
            lock (this.thisLock)
            {
                // Set a new timer interval.
                this.timer.Interval = Math.Max(new Random().Next((int)this.period - (int)this.variance,
                                                                 (int)this.period + (int)this.variance), 1);

                // push the data into the callback, with current time.
                this.callback(new CallCenterRequestEventType(), DateTime.Now);
            }
        }

        /// <summary>
        /// Period at which to produce a new data item.
        /// </summary>
        private uint period;

        /// <summary>
        /// Maximum variance to deviate from the exact period.
        /// </summary>
        private int variance;

        /// <summary>
        /// Timer used to trigger the generation of new data items.
        /// </summary>
        private System.Timers.Timer timer;

        /// <summary>
        /// Mutex for the timer-triggered data generation.
        /// </summary>
        private object thisLock = new object();

        /// <summary>
        /// Callback object.
        /// </summary>
        private EventCallback callback;

        /// <summary>
        /// Callback type to push new data to.
        /// </summary>
        /// <param name="data">New data item to push to the callback.</param>
        /// <param name="timestamp">Timestamp of the data.</param>
        public delegate void EventCallback(CallCenterRequestEventType data, DateTime timestamp);
    }
}
