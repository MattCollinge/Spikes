﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.ComplexEventProcessing;
using Microsoft.ComplexEventProcessing.Adapters;

namespace DataPublisher
{
    class CallCenterAdapterPoint : TypedPointInputAdapter<CallCenterRequestEventType>
    {
        private FakeDataSource dataSource;

        public CallCenterAdapterPoint()
        {
            this.dataSource = new FakeDataSource();
            this.dataSource.Callback = new FakeDataSource.EventCallback(this.ProduceEvents);
        }

        public override void Resume()
        {
            this.dataSource.Start();
        }

        public override void Start()
        {
            this.dataSource.Start();
        }

        private void ProduceEvents(CallCenterRequestEventType data, DateTime timestamp)
        {
            // Check for the stopping state and stop if necessary.
            if (AdapterState.Stopping == AdapterState)
            {
                this.dataSource.Stop();
                Stopped();
                return;
            }

            // Since this method is called from a thread that is independend of
            // Start() and Resume(), we need to make sure that the adapter is
            // actually running.
            if (AdapterState.Running != AdapterState)
            {
                // Throw away the current event.
                return;
            }

            PointEvent<CallCenterRequestEventType> currEvent = CreateInsertEvent();
            if (null == currEvent)
            {
                // Throw away the current event.
                return;
            }

            currEvent.StartTime = timestamp;

            currEvent.Payload = data;

            if (EnqueueOperationResult.Full == Enqueue(ref currEvent))
            {
                ReleaseEvent(ref currEvent);
                Ready();
                return;
            }
        }
    }
}
