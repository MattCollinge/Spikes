﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataPublisher
{
    public class CallEventSummary
    {
        public string RequestType { get; set; }
        public long TotalRequests { get; set; }
    }
}
