﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataPublisher
{
    public struct CallCenterAdapterConfig
    {
        /// <summary>
        /// Gets or sets how often to send a CTI event (1 = send a CTI event with every data event).
        /// </summary>
        public uint CtiFrequency { get; set; }
    }
}
