﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.ComplexEventProcessing;
using Microsoft.ComplexEventProcessing.Adapters;

namespace DataPublisher
{
    public class CallCenterAdapterFactory : ITypedInputAdapterFactory<CallCenterAdapterConfig>, 
        ITypedDeclareAdvanceTimeProperties<CallCenterAdapterConfig>
    {

        public InputAdapterBase Create<TPayload>(CallCenterAdapterConfig configInfo, EventShape eventShape)
        {
            InputAdapterBase adapter = default(InputAdapterBase);

            adapter = new CallCenterAdapterPoint();

            return adapter;
        }

        public void Dispose()
        {
        }



        #region ITypedDeclareAdvanceTimeProperties<CallCenterAdapterConfig> Members

        public AdapterAdvanceTimeSettings DeclareAdvanceTimeProperties<TPayload>(CallCenterAdapterConfig configInfo, EventShape eventShape)
        {
            return new AdapterAdvanceTimeSettings(
                new AdvanceTimeGenerationSettings(configInfo.CtiFrequency, TimeSpan.FromTicks(-1)),
                AdvanceTimePolicy.Drop);
        }

        #endregion
    }
}
