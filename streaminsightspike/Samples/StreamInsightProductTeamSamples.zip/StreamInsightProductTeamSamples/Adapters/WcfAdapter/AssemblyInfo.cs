﻿// *********************************************************
//
//  Copyright (c) Microsoft. All rights reserved.
//  This code is licensed under the Apache 2.0 License.
//  THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OR
//  CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED,
//  INCLUDING, WITHOUT LIMITATION, ANY IMPLIED WARRANTIES
//  OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR
//  PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
// *********************************************************

using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("StreamInsight.Samples.Adapters.Wcf")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct("StreamInsight.Samples.Adapters.Wcf")]
[assembly: AssemblyCopyright("Copyright © Microsoft Corporation 2010")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
